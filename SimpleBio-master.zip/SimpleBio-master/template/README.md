### Simple Bio Template
##### Author - Vinit Shahdeo

This is a basic template for personal bio.

It is for the people who have just started with web development and learnt basic HTML tags and little bit of CSS.

Made for a hands on workshop conducted by me.
