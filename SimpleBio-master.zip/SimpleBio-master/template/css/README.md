#### Stylsheet for Simple Bio template.

##### Authored by Vinit Shahdeo
