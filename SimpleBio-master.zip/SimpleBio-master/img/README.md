###### It contains all the PNG images.
